
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/dam-assets.js
import { getStore } from "@netlify/blobs";
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Content-Type": "application/json"
};
var dam_assets_default = async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }
  const store = getStore("dam-case-assets");
  if (req.method === "POST") {
    try {
      const body = await req.json();
      const { case_number, asset_id, asset_name, asset_url, asset_type, thumbnail_url } = body;
      if (!case_number || !asset_id) {
        return new Response(
          JSON.stringify({ error: "case_number and asset_id are required" }),
          { status: 400, headers: CORS }
        );
      }
      let existing = { assets: [] };
      try {
        existing = await store.get(`case-${case_number}`, { type: "json" });
        if (!existing) existing = { assets: [] };
      } catch (e) {
        existing = { assets: [] };
      }
      if (!existing.assets.find((a) => a.id === asset_id)) {
        existing.assets.push({
          id: asset_id,
          name: asset_name || "Untitled Asset",
          type: asset_type || "raw_file",
          thumbnail: thumbnail_url || null,
          dam_url: asset_url || `https://app.cmp.optimizely.com/assets/${asset_id}`,
          linked_at: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
      await store.setJSON(`case-${case_number}`, {
        caseNumber: case_number,
        assets: existing.assets,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      });
      return new Response(
        JSON.stringify({
          success: true,
          case_number,
          total_assets: existing.assets.length
        }),
        { status: 200, headers: CORS }
      );
    } catch (err) {
      return new Response(
        JSON.stringify({ error: err.message }),
        { status: 500, headers: CORS }
      );
    }
  }
  const url = new URL(req.url);
  const caseNumber = url.searchParams.get("case_number");
  if (!caseNumber) {
    return new Response(
      JSON.stringify({ error: "case_number parameter is required" }),
      { status: 400, headers: CORS }
    );
  }
  try {
    let data = null;
    try {
      data = await store.get(`case-${caseNumber}`, { type: "json" });
    } catch (e) {
    }
    return new Response(
      JSON.stringify({
        case_number: caseNumber,
        assets: data?.assets || [],
        updated_at: data?.updated_at || null
      }),
      { status: 200, headers: CORS }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: CORS }
    );
  }
};
export {
  dam_assets_default as default
};
